﻿using MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;


namespace MVC.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee

        public ActionResult Index()
        {
            IEnumerable<mvcEmployeeModel> empList;
            HttpResponseMessage response = GlobalClass.WebApiClient.GetAsync(GlobalClass.WebApiClient.BaseAddress).Result;
            var test = response.Content.ReadAsStringAsync().Result;
            empList = response.Content.ReadAsAsync<IEnumerable<mvcEmployeeModel>>().Result;
            return View(empList);

        }

        public ActionResult Create()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Register(mvcEmployeeModel employee)
        {
            if (ModelState.IsValid)
            {                
                employee.Status = "Active";
                HttpResponseMessage response = GlobalClass.WebApiClient.PostAsJsonAsync(GlobalClass.WebApiClient.BaseAddress, employee).Result;
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        public ActionResult Details(int id)
        {
            HttpResponseMessage response = GlobalClass.WebApiClient.GetAsync(GlobalClass.GetUri(id.ToString())).Result;            
            var emp = response.Content.ReadAsAsync<mvcEmployeeModel>().Result;
            return View(emp);
        }

        public ActionResult Edit(int id)
        {            
            HttpResponseMessage response = GlobalClass.WebApiClient.GetAsync(GlobalClass.GetUri(id.ToString())).Result;            
            var emp = response.Content.ReadAsAsync<mvcEmployeeModel>().Result;
            return View(emp);
        }

        [HttpPost]
        public ActionResult Update(mvcEmployeeModel employee)
        {
            if (ModelState.IsValid)
            {
                HttpResponseMessage response = GlobalClass.WebApiClient.PutAsJsonAsync(GlobalClass.WebApiClient.BaseAddress, employee).Result;
                return RedirectToAction("Index");
            }
            return View(employee);
        }
        public ActionResult Delete(int id)
        {            
            HttpResponseMessage response = GlobalClass.WebApiClient.DeleteAsync(GlobalClass.GetUri(id.ToString())).Result;
            return RedirectToAction("Index");
            
        }


    }
}