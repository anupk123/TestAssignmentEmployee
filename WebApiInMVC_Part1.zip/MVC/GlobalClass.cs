﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace MVC
{
    public static class GlobalClass
    {
        public static HttpClient WebApiClient = new HttpClient();

        static GlobalClass()
        {
            WebApiClient.BaseAddress = new Uri("http://localhost:61014/api/Employees");
            WebApiClient.DefaultRequestHeaders.Clear();
            WebApiClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static string GetUri(string parameter)
        {
            return (WebApiClient.BaseAddress + "/" + parameter); 
        }
    }
}