﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC.Models
{
    public class mvcEmployeeModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter First Name.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter Last Name.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter Contact Number.")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid Contact number.Please enter Contact Number.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter Email Address.")]
        [EmailAddress]
        public string Email { get; set; }
        public string Status { get; set; }
    }
}
